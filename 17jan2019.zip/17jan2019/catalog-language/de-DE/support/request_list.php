<?php
// Heading Title
$_['heading_title'] 		= 'My Tickets';
$_['banner_title'] 			= 'My Tickets';

// Text
$_['text_support']			= 'Support';
$_['text_no_results']		= 'No Result!';

// Date
$_['date_format_short']     = 'd M Y (h:i A)';

// Button
$_['button_submit'] 		= 'Create New Ticket';
$_['button_view'] 			= 'View Ticket';

// Column
$_['column_date']			= 'Date Added';
$_['column_department']		= 'Department';
$_['column_ticketid']		= 'Ticket ID';
$_['column_subject']		= 'Subject';
$_['column_status']			= 'Status';
$_['column_date_modified']	= 'Last Activity';
$_['column_action']			= 'Action';

//Kreatiwe customization
$_['column_shop']			        = 'Geschäft';
$_['column_consumer']	            = 'Verbraucher';
$_['column_purchased']		        = 'Gekauft';
$_['column_text_online']	        = 'Online';
$_['text_head_merchant_registered']	= 'Registrierte Tickets für';
$_['entry_model']	                = 'Modell';
$_['entry_error_code']	            = 'Fehlercode';
$_['entry_color']	                = 'Farbe';
$_['entry_seat']	                = 'Sitz';
$_['entry_shape']	                = 'Gestalten';
$_['entry_shop_city']	            = 'Shop-Stadt';