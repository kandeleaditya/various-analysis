<?php
// Heading Title
$_['heading_title'] 		= 'Mijn Tickets';
$_['banner_title'] 			= 'Mijn Tickets';

// Text
$_['text_support']			= 'Support';
$_['text_no_results']		= 'Geen Resultaat!';

// Date
$_['date_format_short']     = 'd M Y (h:i A)';

// Button
$_['button_submit'] 		= 'Aanmaken Nieuw Ticket';
$_['button_view'] 			= 'Open Ticket';

// Column
$_['column_date']			= 'Datum toegevoegd';
$_['column_department']		= 'Afdeling';
$_['column_ticketid']		= 'Ticket ID';
$_['column_subject']		= 'Onderwerp';
$_['column_status']			= 'Status';
$_['column_date_modified']	= 'Laaste Activiteit';
$_['column_action']			= 'Actie';

//Kreatiwe customization
$_['column_shop']			        = 'Winkel';
$_['column_consumer']	            = 'Klant';
$_['column_purchased']		        = 'Gekocht';
$_['column_text_online']	        = 'Online';
$_['text_head_merchant_registered']	= 'Geregistreerde kaarten voor';
$_['entry_model']	                = 'Model';
$_['entry_error_code']	            = 'Foutcode';
$_['entry_color']	                = 'Kleur';
$_['entry_seat']	                = 'stoel';
$_['entry_shape']	                = 'Vorm';
$_['entry_shop_city']	            = 'Winkelstad';