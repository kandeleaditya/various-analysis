<?php
// Heading Title
$_['heading_title'] 		= 'My Tickets';
$_['banner_title'] 			= 'My Tickets';

// Text
$_['text_support']			= 'Support';
$_['text_no_results']		= 'No Result!';

// Date
$_['date_format_short']     = 'd M Y (h:i A)';

// Button
$_['button_submit'] 		= 'Create New Ticket';
$_['button_view'] 			= 'View Ticket';

// Column
$_['column_date']			= 'Date Added';
$_['column_department']		= 'Department';
$_['column_ticketid']		= 'Ticket ID';
$_['column_subject']		= 'Subject';
$_['column_status']			= 'Status';
$_['column_date_modified']	= 'Last Activity';
$_['column_action']			= 'Action';

//Kreatiwe customization
$_['column_shop']			        = 'Shop';
$_['column_consumer']	            = 'Consumer';
$_['column_purchased']		        = 'Purchased';
$_['column_text_online']	        = 'Online';
$_['text_head_merchant_registered']	= 'Registered Tickets For';
$_['entry_model']	                = 'Model';
$_['entry_error_code']	            = 'Error Code';
$_['entry_color']	                = 'Color';
$_['entry_seat']	                = 'Seat';
$_['entry_shape']	                = 'Shape';
$_['entry_shop_city']	            = 'Shop City';