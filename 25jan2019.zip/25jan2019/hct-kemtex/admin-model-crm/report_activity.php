<?php
class ModelCrmReportActivity extends Model {
	public function getActivities($user_id) {
		$customers = "select customer_id from `" . DB_PREFIX . "customer` where erp_id IN (select erp_id from " . DB_PREFIX . "gs_customer_to_user where user_id = '" . $this->db->escape($user_id) . "')";
		
		$query = $this->db->query("SELECT a.key, a.data, a.date_added FROM ((SELECT CONCAT('customer_', ca.key) AS `key`, ca.data, ca.date_added FROM `" . DB_PREFIX . "customer_activity` ca where ca.customer_id IN (".$customers.")) UNION (SELECT CONCAT('affiliate_', aa.key) AS `key`, aa.data, aa.date_added FROM `" . DB_PREFIX . "affiliate_activity` aa)) a ORDER BY a.date_added DESC LIMIT 0,5");

		return $query->rows;
	}
}