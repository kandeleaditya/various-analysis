<?php
class ControllerSupportTicketuser extends Controller {
	public function login() {
		$this->load->language('support/ticketuser');

		$json = array();

		if ($this->ticketuser->isLogged()) {
			$json['redirect'] = $this->url->link('support/support', '', true);
		}

		if (!$json) {
			$this->load->model('module_ticket/ticketuser');

			// Check if ticket user has been approved.
			$ticketuser_info = $this->model_module_ticket_ticketuser->getTicketuserByEmail($this->request->post['email']);

			if ($ticketuser_info && empty($ticketuser_info['status'])) {
				$json['error']['warning'] = $this->language->get('error_approved');
			}

			if (!isset($json['error'])) {
				if (!$this->ticketuser->login($this->request->post['email'], $this->request->post['password'])) {
					$json['error']['warning'] = $this->language->get('error_login');
				}
			}
		}

		if (!$json) {
			if (isset($this->session->data['support_redirect']) && $this->session->data['support_redirect'] != $this->url->link('support/logout', '', true) && (strpos($this->session->data['support_redirect'], $this->config->get('config_url')) !== false || strpos($this->session->data['support_redirect'], $this->config->get('config_ssl')) !== false)) {
				$json['redirect'] = str_replace('&amp;', '&', $this->session->data['support_redirect']);
			} else {
				$json['redirect'] = $this->url->link('support/support', '', true);
			}

			unset($this->session->data['support_redirect']);
		}
		// Kreatiwe changes GDRP start
		$this->customer->login($this->request->post['email'], $this->request->post['password']);
		// Kreatiwe changes GDRP end
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function forgot() {
		$this->load->language('support/ticketuser');
		$this->load->model('module_ticket/ticketuser');

		$json = array();

		if ($this->ticketuser->isLogged()) {
			$json['redirect'] = $this->url->link('support/support', '', true);
		}

		if (!isset($this->request->post['email'])) {
			$json['error']['warning'] = $this->language->get('error_email');
		} elseif (!$this->model_module_ticket_ticketuser->getTotalTicketusersByEmail($this->request->post['email'])) {
			$json['error']['warning'] = $this->language->get('error_email');
		}

		$ticketuser_info = $this->model_module_ticket_ticketuser->getTicketuserByEmail($this->request->post['email']);

		if ($ticketuser_info && empty($ticketuser_info['status'])) {
			$json['error']['warning'] = $this->language->get('error_approved');
		}

		if(!$json) {
			$password = substr(sha1(uniqid(mt_rand(), true)), 0, 10);

			$this->model_module_ticket_ticketuser->editPassword($this->request->post['email'], $password);

			$ticketsetting_email = (array)$this->config->get('ticketsetting_email');

			// Send Email To User for forgot password
			if(!empty($ticketsetting_email['forgotpasswordtouser']['status'])) {
				$this->load->language('support/mail_userpassword');

				$subject = sprintf($this->language->get('text_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));

				$message  = sprintf($this->language->get('text_greeting'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8')) . "\n\n";
				$message .= $this->language->get('text_password') . "\n\n";
				$message .= $password;

				if(VERSION <= '2.0.1.1') {
			     	$mail = new Mail($this->config->get('config_mail'));
			    } else {
					$mail = new Mail();
					$mail->protocol = $this->config->get('config_mail_protocol');
					$mail->parameter = $this->config->get('config_mail_parameter');
					$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
					$mail->smtp_username = $this->config->get('config_mail_smtp_username');
					$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
					$mail->smtp_port = $this->config->get('config_mail_smtp_port');
					$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
				}

				$mail->setTo($this->request->post['email']);
				$mail->setFrom($this->config->get('config_email'));
				$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
				$mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
				$mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
				$mail->send();
			}

			$json['success'] = $this->language->get('text_forgotsuccess');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function register() {
		$json = array();

		$this->load->language('support/ticketuser');

		$this->load->model('module_ticket/ticketuser');

		if ($this->ticketuser->isLogged()) {
			$json['redirect'] = $this->url->link('support/support', '', true);
		}

		// Kreatowe changes start
		if ((utf8_strlen(trim($this->request->post['firstname'])) < 1) || (utf8_strlen(trim($this->request->post['firstname'])) > 32)) {
			$json['error']['option']['firstname'] = $this->language->get('error_firstname');
		}
		if ((utf8_strlen(trim($this->request->post['lastname'])) < 1) || (utf8_strlen(trim($this->request->post['lastname'])) > 32)) {
			$json['error']['option']['lastname'] = $this->language->get('error_lastname');
		}
		// Kreatiwe changes end

		if ((utf8_strlen($this->request->post['email']) > 96) || !filter_var($this->request->post['email'], FILTER_VALIDATE_EMAIL)) {
			$json['error']['option']['email'] = $this->language->get('error_found_email');
		}

		if ($this->model_module_ticket_ticketuser->getTotalTicketusersByEmail($this->request->post['email'])) {
			$json['error']['warning'] = $this->language->get('error_exists');
		}

		if ((utf8_strlen($this->request->post['password']) < 4) || (utf8_strlen($this->request->post['password']) > 20)) {
			$json['error']['option']['password'] = $this->language->get('error_password');
		}

		if ($this->request->post['confirm'] != $this->request->post['password']) {
			$json['error']['option']['confirm'] = $this->language->get('error_confirm');
		}

		// Kreatiwe changes start
		if ((utf8_strlen(trim($this->request->post['address_1'])) < 1)) {
			$json['error']['option']['address_1'] = $this->language->get('error_address_1');
		}
		if ((utf8_strlen(trim($this->request->post['address_2'])) < 1)) {
			$json['error']['option']['address_2'] = $this->language->get('error_address_2');
		}
		if ((utf8_strlen(trim($this->request->post['city'])) < 1)) {
			$json['error']['option']['city'] = $this->language->get('error_city');
		}
		if ((utf8_strlen(trim($this->request->post['postcode'])) < 1)) {
			$json['error']['option']['postcode'] = $this->language->get('error_postcode');
		}
		if ((utf8_strlen(trim($this->request->post['country_id'])) < 1)) {
			$json['error']['option']['country_id'] = $this->language->get('error_country_id');
		}
		if ((utf8_strlen(trim($this->request->post['zone_id'])) < 1)) {
			$json['error']['option']['zone_id'] = $this->language->get('error_zone_id');
		}
		if ((utf8_strlen(trim($this->request->post['telephone'])) < 1)) {
			$json['error']['option']['telephone'] = $this->language->get('error_telephone');
		}

		// Agree to terms
		if ($this->config->get('config_account_id')) {
			$this->load->model('catalog/information');

			$information_info = $this->model_catalog_information->getInformation($this->config->get('config_account_id'));

			if ($information_info && $this->request->post['agree'] == "0") {
				$json['error']['option']['agree'] = sprintf($this->language->get('error_agree'), $information_info['title']);
			}
		}

		/*if ($this->request->post['agree'] == 1) {
			$json['error']['option']['agree'] = $this->language->get('error_agree');
		}*/
		// Kreatiwe changes end


		if(!$json) {
			// Kreatiwe changes start
			$add_data=array(
				'firstname'	=> isset($this->request->post['firstname']) ? $this->request->post['firstname'] : '',
				'lastname'	=> isset($this->request->post['lastname']) ? $this->request->post['lastname'] : '',
				'address_1'	=> isset($this->request->post['address_1']) ? $this->request->post['address_1'] : '',
				'address_2'	=> isset($this->request->post['address_2']) ? $this->request->post['address_2'] : '',
				'city'	=> isset($this->request->post['city']) ? $this->request->post['city'] : '',
				'postcode'	=> isset($this->request->post['postcode']) ? $this->request->post['postcode'] : '',
				'country_id'	=> isset($this->request->post['country_id']) ? $this->request->post['country_id'] : '',
				'zone_id'	=> isset($this->request->post['zone_id']) ? $this->request->post['zone_id'] : '',
				'telephone'	=> isset($this->request->post['telephone']) ? $this->request->post['telephone'] : '',
				'company' => '',
				'email'	=> isset($this->request->post['email']) ? $this->request->post['email'] : '',
				'password'	=> isset($this->request->post['password']) ? $this->request->post['password'] : '',
				'confirm'	=> isset($this->request->post['confirm']) ? $this->request->post['confirm'] : '',
				'default'	=> true,
			);
			// Kreatiwe changes end
			// Kreatiwe changes start
			$this->load->model('account/customer');
			$is_created_from_support = true;
			$customer_id = $this->model_account_customer->addCustomer($add_data,$is_created_from_support);
			// Kreatiwe changes end

			// Kreatiwe changes start
			$ticketuser_id = $this->model_module_ticket_ticketuser->addTicketUser($add_data,$customer_id);
			$this->load->model('account/address');
			$this->model_account_address->addAddress($customer_id, $add_data);
			// Kreatiwe chanegs end

			$this->ticketuser->login($this->request->post['email'], $this->request->post['password']);

			// Kreatiwe changes start
			$json['loggedIn'] = $this->ticketuser->isLogged();
			// Kreatiwe changes end

			$json['success'] = true;

			if (isset($this->session->data['support_redirect']) && $this->session->data['support_redirect'] != $this->url->link('support/logout', '', true) && (strpos($this->session->data['support_redirect'], $this->config->get('config_url')) !== false || strpos($this->session->data['support_redirect'], $this->config->get('config_ssl')) !== false)) {
				$json['redirect'] = str_replace('&amp;', '&', $this->session->data['support_redirect']);
			} else {
				$json['redirect'] = $this->url->link('support/support', '', true);
			}

			unset($this->session->data['support_redirect']);

			$this->load->model('setting/setting');
			$settings = $this->model_setting_setting->getSetting('module_gdpr');
  
			if($settings['module_gdpr_status'] && $settings['module_gdpr_store_policy_acceptance'] && isset($this->request->post['agree'])){
				$this->load->model('account/customer');
				$this->load->model('catalog/information');
				$this->load->model('extension/module/gdpr');

				if(isset($this->request->post['agree'])) {
				  $information_info = $this->model_catalog_information->getInformation($this->config->get('config_account_id'));
				  $policy_data = array(
					'customer_email' => isset($this->request->post['email']) ? $this->request->post['email'] : '',
					'customer_id' => !empty($customer_id) ? $customer_id : 0,
					'date_accepted' => date("Y-m-d H:i:s"),
					'policy_id' => $information_info['information_id'],
					'policy_name' => $information_info['title'],
					'policy_content' => $information_info['description'],
				  );
  
				  $this->model_extension_module_gdpr->storePolicyAcceptance($policy_data);
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function edit() {
		$json = array();

		$this->load->language('support/ticketuser');

		$this->load->model('module_ticket/ticketuser');

		if (!$this->ticketuser->isLogged()) {
			$json['redirect'] = $this->url->link('support/support', 'login=1', true);
		}

		if ((utf8_strlen(trim($this->request->post['name'])) < 1) || (utf8_strlen(trim($this->request->post['name'])) > 32)) {
			$json['error']['option']['name'] = $this->language->get('error_name');
		}

		if ((utf8_strlen($this->request->post['email']) > 96) || !filter_var($this->request->post['email'], FILTER_VALIDATE_EMAIL)) {
			$json['error']['option']['email'] = $this->language->get('error_email');
		}

		if (($this->ticketuser->getEmail() != $this->request->post['email']) && $this->model_module_ticket_ticketuser->getTotalTicketusersByEmail($this->request->post['email'])) {
			$json['error']['option']['email'] = $this->language->get('error_exists');
		}

		if(!$json) {
			$this->model_module_ticket_ticketuser->editTicketuser($this->request->post);

			$json['success'] = $this->language->get('text_editsuccess');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function editPassword() {
		$json = array();

		$this->load->language('support/ticketuser');

		$this->load->model('module_ticket/ticketuser');

		if (!$this->ticketuser->isLogged()) {
			$json['redirect'] = $this->url->link('support/support', 'login=1', true);
		}

		if ((utf8_strlen($this->request->post['password']) < 4) || (utf8_strlen($this->request->post['password']) > 20)) {
			$json['error']['option']['password'] = $this->language->get('error_password');
		}

		if ($this->request->post['confirm'] != $this->request->post['password']) {
			$json['error']['option']['confirm'] = $this->language->get('error_confirm');
		}

		if(!$json) {
			$this->model_module_ticket_ticketuser->editPassword($this->ticketuser->getEmail(), $this->request->post['password']);

			$json['success'] = $this->language->get('text_passwordsuccess');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function imageupload() {
		$this->load->language('tool/upload');

		$this->load->model('tool/image');

		$json = array();

		if (!empty($this->request->files['file']['name']) && is_file($this->request->files['file']['tmp_name'])) {
			// Sanitize the filename
			$filename = basename(preg_replace('/[^a-zA-Z0-9\.\-\s+]/', '', html_entity_decode($this->request->files['file']['name'], ENT_QUOTES, 'UTF-8')));

			// Validate the filename length
			if ((utf8_strlen($filename) < 3) || (utf8_strlen($filename) > 64)) {
				$json['error'] = $this->language->get('error_filename');
			}

			// Allowed file extension types
			$allowed = array();
			$file_ext_allowed = "png\njpe\njpeg\njpg\ngif\nbmp";
			$file_mime_allowed = "image/png\nimage/jpeg\nimage/gif\nimage/bmp";

			$extension_allowed = preg_replace('~\r?\n~', "\n", $file_ext_allowed);

			$filetypes = explode("\n", $extension_allowed);

			foreach ($filetypes as $filetype) {
				$allowed[] = trim($filetype);
			}

			if (!in_array(strtolower(substr(strrchr($filename, '.'), 1)), $allowed)) {
				$json['error'] = $this->language->get('error_filetype');
			}

			// Allowed file mime types
			$allowed = array();

			$mime_allowed = preg_replace('~\r?\n~', "\n", $file_mime_allowed);

			$filetypes = explode("\n", $mime_allowed);

			foreach ($filetypes as $filetype) {
				$allowed[] = trim($filetype);
			}

			if (!in_array($this->request->files['file']['type'], $allowed)) {
				$json['error'] = $this->language->get('error_filetype');
			}

			// Check to see if any PHP files are trying to be uploaded
			$content = file_get_contents($this->request->files['file']['tmp_name']);

			if (preg_match('/\<\?php/i', $content)) {
				$json['error'] = $this->language->get('error_filetype');
			}

			// Return any upload error
			if ($this->request->files['file']['error'] != UPLOAD_ERR_OK) {
				$json['error'] = $this->language->get('error_upload_' . $this->request->files['file']['error']);
			}
		} else {
			$json['error'] = $this->language->get('error_upload');
		}

		if (!$json) {
			$namedire = 'customer-profile';

			$dir = DIR_IMAGE . $namedire . '/';

			if (!file_exists($dir)) {
			    mkdir($dir, 0777, true);
			}

			if (is_file($dir . $filename)) {
				$parts = pathinfo($dir . $filename);
				if($parts) {
					$file = $parts['filename'] . '-' . rand(1, 5000) . '.'. $parts['extension'];
				} else{
					$file = $filename;
				}
			} else{
				$file = $filename;
			}

			move_uploaded_file($this->request->files['file']['tmp_name'], $dir . $file);

			// Hide the uploaded file name so people can not link to it directly.
			$this->load->model('tool/upload');

			$json['success'] = $this->language->get('text_upload');

			$customer_profile = $namedire . '/' . $file;

			$json['customer_profile'] = $customer_profile;

			if (is_file($dir . $file)) {
				$json['customer_thumb'] = $this->model_tool_image->resize($customer_profile, 60, 60);
			} else {
				$json['customer_thumb'] = $this->model_tool_image->resize($namedire . 'avtar.png', 60, 60);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}